<?php

return [
    // 请求成功
    'success' => 200,
    // 未登录
    'not_logged' => 401,
    // 没有权限访问
    'not_permission' => 403,
    // 服务器内部错误
    'error' => 500,
];
